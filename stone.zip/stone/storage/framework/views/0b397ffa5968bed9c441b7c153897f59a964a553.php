

<?php $__env->startSection('content'); ?>

<div class="container">
    <!-- Section: Features v.4 -->
    <section class="my-5" id="features">

      <!-- Secion heading -->
      <h1 class="text-center  mt-5 mb-5 pt-5 mb-4 drk-grey-text wow fadeIn title-font " data-wow-delay="0.2s">
        Rudraksha
        <div  class="mt-2"style="height:3px; background: rgb(121,56,56);
        background: radial-gradient(circle, rgba(121,56,56,1) 44%, rgba(255,255,255,1) 100%);
        ">

        </div>
      </h1>

      <!-- Section description -->
      

      <!-- Grid row -->
      <div class="row wow fadeIn" data-wow-delay="0.4s">

        <?php for($i=1;$i<12;$i++): ?>
         <!-- Grid row -->
         <div class="col-6 col-md-3 col-md-3 text-center pb-4">
          
            <div class="p-3" style=" box-shadow: 3px 3px 7px rgb(0 0 0 / 25%)">
                <img src="<?php echo e(asset('images/2.png')); ?>" alt="" height="150px" width="150px">
                <h6 class="">BLUE SAPPHIRE</h6>
            </div>
  
        </div>
        <!-- Grid row -->
       
           <?php endfor; ?> 
    

      </div>
      <!-- Grid row -->
     
    </section>
    <!-- Section: Features v.4 -->

  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\stone-store\stone\resources\views/website/categories.blade.php ENDPATH**/ ?>