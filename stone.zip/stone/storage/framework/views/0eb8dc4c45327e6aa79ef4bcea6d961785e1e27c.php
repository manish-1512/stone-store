<?php $__env->startSection('content'); ?>

<div class="card">
  <img src="<?php echo e(asset('images/about_banner.jpg')); ?>" class="img-fluid" width="100%" alt="Responsive image">  
</div>

    <div class="site-section">
      <div class="container">

        

        <div class="row mb-5">
          <div class="col-md-12 order-2">

            <div class="row">
              <div class="col-md-12 mb-5">
                <div class="float-md-left mb-4"><h2 class="text-black h5">Shop All</h2></div>
                <div class="d-flex">
                  <div class="dropdown mr-1 ml-md-auto">
                    <button type="button" class="btn btn-secondary btn-sm dropdown-toggle"data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                      filter
                    </button>
                    
                    
                  </div>
                  <div class="btn-group">
                    <button type="button" class="btn btn-secondary btn-sm dropdown-toggle" id="dropdownMenuReference" data-toggle="dropdown">Reference</button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuReference">
                      <a class="dropdown-item" href="#">Relevance</a>
                      <a class="dropdown-item" href="#">Name, A to Z</a>
                      <a class="dropdown-item" href="#">Name, Z to A</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">Price, low to high</a>
                      <a class="dropdown-item" href="#">Price, high to low</a>
                    </div>
                  </div>
                </div>
                <div class="collapse mt-2 card card-body" id="collapseExample">
                  <div class=" ">
                    <div class="row">
                        <div class="col-4">
                          <div class="mb-4">
                            <h3 class="mb-3 h6 text-uppercase text-black d-block">Filter by Price</h3>
                            <div id="slider-range" class="border-primary"></div>
                            <input type="text" name="text" id="amount" class="form-control border-0 pl-0 bg-white" disabled="" />
                          </div>

                        </div>
                        <div class="col-6">
                          <div class="mb-4">
                            <h3 class="mb-3 h6 text-uppercase text-black d-block">Filter by Carat</h3>
                            <div class="mb-4">
                              <h3 class="mb-3 h6 text-uppercase text-black d-block">CARAT</h3>
                              <label for="s_sm" class="d-flex">
                                <input type="checkbox" id="s_sm" class="mr-2 mt-1"> <span class="text-black">Small (2,319)</span>
                              </label>
                              <label for="s_md" class="d-flex">
                                <input type="checkbox" id="s_md" class="mr-2 mt-1"> <span class="text-black">Medium (1,282)</span>
                              </label>
                              <label for="s_lg" class="d-flex">
                                <input type="checkbox" id="s_lg" class="mr-2 mt-1"> <span class="text-black">Large (1,392)</span>
                              </label>
                            </div>
                          </div>

                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row mb-5">

              <?php for($i=1;$i<20;$i++): ?>    
                <div class="col-sm-6 col-lg-3 mb-4" data-aos="fade-up">
                  <div class="block-4 text-center border">
                    <figure class="block-4-image position-relative">
                      <a href="<?php echo e(route('product-details')); ?>"><img src="images/most3.jpg"  alt="Image placeholder" class="img-fluid"></a>

                      <a href="asaasasas" class="position-absolute" style="top:5px;right:1px"><span class="p-1"><i class="fa fa-heart text-white fa-2x" > </span></i></a>
                    </figure>
                    <div class="block-4-text p-4">
                      <h5><a href="<?php echo e(route('product-details')); ?>">Blue Sapphire (Neelam) Sri Lanka- 8.62 Carat (9.50 Ratti)</a></h5>
                      <p class="text-primary font-weight-bold"> $50 </p>
                    </div>
                  </div>
                </div>
              
             <?php endfor; ?>


            </div>
            <div class="row" data-aos="fade-up">
              <div class="col-md-12 text-center">
                <div class="site-block-27">
                  <ul>
                    <li><a href="#">&lt;</a></li>
                    <li class="active"><span>1</span></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    <li><a href="#">&gt;</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          
        </div>

        
        
      </div>
    </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\stone-store\stone\resources\views/website/shop.blade.php ENDPATH**/ ?>