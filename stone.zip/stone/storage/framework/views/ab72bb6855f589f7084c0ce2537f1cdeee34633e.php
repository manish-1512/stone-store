

<?php $__env->startSection('content'); ?>

 <!-- Content Header (Page header) -->
 <div class="content-header">
    <div class="container-fluid">
      <div class="row ">
        <div class="col-sm-6">
          <h1 class="m-0">Edit  Cms </h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item"> <a href="<?php echo e(route('admin.cms.show')); ?>"> Cms Pages </a></li>
            <li class="breadcrumb-item active">Edit Cms Pages</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <section class="content p-lg-5 p-2">
    <div class="card card-primary">
      <div class="card-header">
        <h3 class="card-title">Edit</h3>
      </div>
      <!-- /.card-header -->
        
        <div class="card-body">

          <form action="<?php echo e(route('admin.cms.update')); ?>" method="post" >

            <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="exampleInputEmail1">Page Title</label>
            <input type="hidden" name="slug"  value="<?php echo e($data->slug); ?>" >
            <input type="text" name="title" value="<?php echo e($data->title); ?>" class="form-control" >
          </div>
          <div class="form-group">
            <label for="exampleInputFile">Banner </label>
            <div class="input-group">
              <div class="custom-file">
                <input type="file" name="banner" class="custom-file-input" id="exampleInputFile">
                <label class="custom-file-label" for="exampleInputFile">Choose file</label>
              
              </div>
              <div class="input-group-append">
                <span class="input-group-text">Upload </span>
              </div>
            </div>
            <img src="<?php echo e(asset(WEBSITE_BANNER)); ?>/<?php echo e($data->banner); ?>"  alt="" height="120">
          </div>
             <!-- Main content -->
        <section class="content">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card card-outline card-info">
                      <div class="card-header">
                        <h3 class="card-title">
                          Description
                        </h3>
                      </div>
                      <!-- /.card-header -->
                      <div class="card-body">
                        <textarea id="editor1" name="body"><?php echo e($data->body); ?></textarea>
                      </div>
                      <div class="card-footer">
                        
                      </div>
                    </div>
                  </div>
                  <!-- /.col-->
                </div>
      
          </section>
          <!-- /.content -->
          <div class="form-group">
            <label >Meta Title </label>
            <input type="text" name="meta_title" value="<?php echo e($data->meta_title); ?>" class="form-control"  placeholder="Enter Meta Title">
          </div>
          <div class="form-group">
            <label >Meta Description</label>
            <textarea name="meta_description" id=""  cols="30"  class="form-control" rows="6"><?php echo e($data->meta_description); ?></textarea>
          </div>
          <div class="form-group">
              <label for="exampleInputEmail1">Meta Keyword</label>
              <input type="text" name="meta_keywords" value="<?php echo e($data->meta_keywords); ?>" class="form-control"  placeholder="Enter Meta Keyword ">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1"></label>
            <button type="submit" class="btn btn-success">Update </button>
            <a  class="btn btn-danger" href="<?php echo e(route('admin.cms.show')); ?>" >Cancle </a>
            <a  class="btn btn-danger" href="<?php echo e(route('admin.cms.show')); ?>" >Cancle </a>
        </div>
          
        </div>
        <!-- /.card-body -->
      </form>
      
    
    </div>

  </section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/30.0.0/classic/ckeditor.js"></script>
<script>
  ClassicEditor
      .create( document.querySelector( '#editor1' ) )
      .catch( error => {
          console.error( error );
      } );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\stone-store\stone\resources\views/admin/cms/edit.blade.php ENDPATH**/ ?>