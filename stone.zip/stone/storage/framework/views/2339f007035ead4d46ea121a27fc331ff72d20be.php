



<?php $__env->startSection('content'); ?>

 <!-- Content Header (Page header) -->
 <div class="content-header">
    <div class="container-fluid">
      <div class="row ">
        <div class="col-sm-6">
          <h1 class="m-0">Cms Pages </h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item active">Cms Pages</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->



   

    <!-- Main content -->
    <section class="content ">
      
      
            

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Cms Pages </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered">
                  <thead>
                  <tr>
                    <th>Page Name</th>
                    <th>Action</th>
                    
                  </tr>
                  </thead>
                  <tbody>

                   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    <td><?php echo e($item->name); ?></td>
                    <td> <a href="<?php echo e(route('admin.cms.edit',$item->slug)); ?>" class="btn btn-outline-info " > <i class="fas fa-edit"></i> </a> </td>
                    
                  </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                  
                 

                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Page Name</th>
                    <th>Action</th>
                    
                    
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
         
   
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\stone-store\stone\resources\views/admin/cms/index.blade.php ENDPATH**/ ?>