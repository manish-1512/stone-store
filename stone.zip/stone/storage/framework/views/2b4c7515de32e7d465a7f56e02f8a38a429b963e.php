

<?php $__env->startSection('content'); ?>

 <!-- Content Header (Page header) -->
 <div class="content-header">
    <div class="container-fluid">
      <div class="row ">
        <div class="col-12 col-md-6">
          <h1 class="m-0">Product Categories </h1>
        </div><!-- /.col -->
        <div class="col-12 col-md-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item"> <a href="<?php echo e(route('admin.cms.show')); ?>"> Categories </a></li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <div class="container-fluid">
    <div class="row px-3">
        <p>
          List Of  Product Categories
        </p>
    </div>
    <div class="row p-3 ">

       
      <div class="col-sm-6 bg-light ">
        <div id="accordion" class="myaccordion">

          <?php $__currentLoopData = $top_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="card">
            <div class="card-header" id="<?php echo e($category->slug); ?>2">
              <div class="d-flex  justify-content-between">
                  <h2 class="mb-0">
                   
                    <button class="d-flex align-items-center justify-content-between btn btn-link collapsed" data-toggle="collapse" data-target="#<?php echo e($category->slug); ?>" aria-expanded="false" aria-controls="<?php echo e($category->slug); ?>">
                      <?php echo e($category->name); ?>

                      <span class="fa-stack fa-sm">
                        <i class="fas fa-circle fa-stack-2x"></i>
                        <i class="fas fa-plus fa-stack-1x fa-inverse"></i>
                      </span>
                    
                    </button>
                   
                  </h2>
                  <a href="#"> <i class="fa fa-edit"></i></a>

              </div>
            </div>
            <div id="<?php echo e($category->slug); ?>" class="collapse" aria-labelledby="<?php echo e($category->slug); ?>2" data-parent="#accordion">
              <div class="card-body">
                  
                          <?php $sub_category =  DB::table('categories')->where('parent_id',$category->id)->get();?>

                          <?php if( count($sub_category) > 0): ?>

                          <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <div class="card">
                            <div class="card-header" id="<?php echo e($category->slug); ?>3">
                              <div class="d-flex  justify-content-between">
                                  <h2 class="mb-0">
                                   
                                    <button class="d-flex align-items-center justify-content-between btn btn-link collapsed" data-toggle="collapse" data-target="#<?php echo e($sub_cat->slug); ?>" aria-expanded="false" aria-controls="<?php echo e($sub_cat->slug); ?>">
                                      <?php echo e($sub_cat->name); ?>

                                      <span class="fa-stack fa-sm">
                                        <i class="fas fa-circle fa-stack-2x"></i>
                                        <i class="fas fa-plus fa-stack-1x fa-inverse"></i>
                                      </span>
                                    
                                    </button>
                                   
                                  </h2>
                                  <a href="#"> <i class="fa fa-edit"></i></a>
                
                              </div>
                            </div>
                            <div id="<?php echo e($sub_cat->slug); ?>" class="collapse" aria-labelledby="<?php echo e($category->slug); ?>3" data-parent="#accordion">
                              <div class="card-body">
                                  
                                          
                
                                
                              </div>
                            </div>
                          </div>
                
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                          <?php endif; ?>

                
              </div>
            </div>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           
           
          </div>
      </div><!-- /.col -->
      <div class="col-sm-6 bg-light">
            
        <div class="p-4 border">

            <form action="<?php echo e(route('admin.categories.store')); ?>" method="post"  enctype="multipart/form-data" >
  
              <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="exampleInputEmail1">Name</label>
             
              <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" >
              <?php if($errors->has('name')): ?>
                    <span class="error text-danger"><?php echo e($errors->first('name')); ?></span>
              <?php endif; ?>
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Hindi Name</label>
            
              <input type="text" name="hindi_name" value="<?php echo e(old('hindi_name')); ?>" class="form-control" >
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Parent Category</label>
                <select name="parent_id" id="" class="form-control"  >
                    <option value="">NO Parent</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
               
            </div>
            <div class="form-group">
              <label for="exampleInputFile">Banner </label>
              <div class="input-group">
                <div class="custom-file">
                  <input type="file" name="banner" class="custom-file-input" id="exampleInputFile">
                  <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                
                </div>
                <div class="input-group-append">
                  <span class="input-group-text">Upload </span>
                </div>
               
              </div>
              <?php if($errors->has('banner')): ?>
              <span class="error text-danger"><?php echo e($errors->first('banner')); ?></span>
             <?php endif; ?>
            </div>
            <div class="form-group">
              <label >Short Description</label>
              <textarea name="short_description" id="short_description"  cols="30"  class="form-control"placeholder="Short Description"  rows="6"><?php echo e(old('short_description')); ?></textarea>
            </div>
            <div class="form-group">
              <label >Description</label>
              <textarea name="description" id="description"  cols="30"  class="form-control" placeholder="Description" rows="6"><?php echo e(old('description')); ?></textarea>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Order</label>
                <input type="number" name="order"   class="form-control" value="<?php echo e(old('order')); ?>" >
                <?php if($errors->has('order')): ?>
                <span class="error text-danger"><?php echo e($errors->first('order')); ?></span>
               <?php endif; ?>
            </div>

            <div class="form-group">
              <label for="exampleInputEmail1"></label>
              <button type="submit" class="btn btn-success">Save </button>
          
              <a  class="btn btn-danger" href="" >Cancle </a>
          </div>
            
          </div>
          <!-- /.card-body -->
          </form>
        </div>

      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->




  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('scripts'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/30.0.0/classic/ckeditor.js"></script>
<script>
  ClassicEditor
      .create( document.querySelector( '#short_description' ) )
      .catch( error => {
          console.error( error );
      } );
</script>
<script>
    ClassicEditor
        .create( document.querySelector( '#description' ) )
        .catch( error => {
            console.error( error );
        } );
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\stone-store\stone\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>