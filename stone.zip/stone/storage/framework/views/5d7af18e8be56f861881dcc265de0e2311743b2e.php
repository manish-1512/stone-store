<?php echo e($slot); ?>

<?php /**PATH D:\project\stone-store\stone\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>