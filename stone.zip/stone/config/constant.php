<?php

define("LOGO_IMAGE_URL","uploads/settings/");
define("FAVICON_IMAGE_URL","uploads/settings/");
define("WEBSITE_BANNER","uploads/website/banners/");
define("CATEGORY_BANNER","uploads/website/categories/");

?>